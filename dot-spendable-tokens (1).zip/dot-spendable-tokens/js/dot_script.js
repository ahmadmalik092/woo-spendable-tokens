jQuery( document ).ready(function() {
    
    //alert( "ready!" );
    
});
//dot_set_token_fee_global
jQuery('#dot_set_token_fee_global').on('click',function(event){
    event.preventDefault();
    jQuery( '#dot_status_global' ).html( 'Dot is now setting Token Fee.... (wait)' );
    
    var dot_token_fee = jQuery('#dot_token_fee_global').val();

    if(!dot_token_fee){
        jQuery( '#dot_status' ).html( 'Error: Either Token Value or Token fee is empty.' );
        return;
    }else{
        var dataa = {
            dot_token_fee: dot_token_fee,
            action: 'dot_set_token_fee'
        };   
        jQuery.post( ajax_url, dataa, function(response) {  
            console.log(response);
            jQuery( '#dot_status_global' ).html( response.message );
        });
    }
    
});

jQuery('#dot_create_st').on('click',function(event){
    event.preventDefault();
    jQuery( '#dot_status' ).html( 'Dot is now Creating New Spendable Token.... (wait)' );
    
    var dot_token_value = jQuery('#dot_token_value').val();
    var dot_token_fee = jQuery('#dot_token_fee').val();

    if(!dot_token_value || !dot_token_fee){
        jQuery( '#dot_status' ).html( 'Error: Either Token Value or Token fee is empty.' );
        return;
    }else{
        var dataa = {
            dot_token_value: dot_token_value,
            dot_token_fee: dot_token_fee,
            action: 'dot_create_token'
        };   
        jQuery.post( ajax_url, dataa, function(response) {  
            console.log(response);
            jQuery( '#dot_status' ).html( response.message );
        });
    }
    
});

jQuery('.dot_delete_token').on('click',function(event){
    event.preventDefault();
    var dot_token= jQuery(this).data('st');
    
    
    if(!dot_token){
        jQuery( '.dot_status_'+dot_token ).html( 'Ivalid Token.' );
        return;
    }else{
        jQuery( '.dot_status_'+dot_token ).html( 'Deleting Token. Wait!' );
        var dataa = {
            dot_token: dot_token,
            action: 'dot_delete_token'
        };   
        jQuery.post( ajax_url, dataa, function(response) {  
            console.log(response);
            jQuery( '.dot_status_'+dot_token ).html( 'Token Deleted!' );
        });
    }
    

    
});