jQuery( document ).ready(function() {
    //alert( "ready!" );
        
    jQuery('#dot_check_availability').on('submit', function(event){
        event.preventDefault();

        var dot_street = jQuery('#form-field-dot_street').val();
        var dot_house = jQuery('#form-field-dot_house').val();
        var dot_zip = jQuery('#form-field-dot_zip').val();
        var dot_town = jQuery('#form-field-dot_town').val();

        console.log(dot_street);

        var dataa = {
            action: 'dot_check_availability',
            dot_street: dot_street,
            dot_house: dot_house,
            dot_zip: dot_zip,
            dot_town: dot_town,
        }; 

        jQuery.post( ajax_url, dataa, function(response) {  
            console.log(response);
            $status = "Error";
            if(response.found_status == 0){
                setTimeout(function () {
                    $status = "Area Not Found!";
                	jQuery( '#dot_status h2' ).html( $status );
                	jQuery( '#dot_message p' ).html( response.message );
                }, 1500);
                
            }
            if(response.found_status == 1){
                $status = "Area Found!";
                jQuery( '#dot_status h2' ).html( $status );
                jQuery( '#dot_message p' ).html( response.message );
                setTimeout(function () {
                    window.location.replace(response.dot_redirect);
                }, 2000);
                

            }
            if(response.found_status == 2){
                
                setTimeout(function () {
                    $status = "We're not sure!";
                	jQuery( '#dot_status h2' ).html( $status );
                	jQuery( '#dot_message p' ).html( response.message );
                }, 1500);
            }
            
        });


        console.log('hello');
    });

    


});