<?php

// {} = []
// get an option
        global $wpdb;
        
        $tblname = 'UserSpendableTokens';
    	$wp_track_table = $wpdb->prefix . "$tblname";
        $dot_options = $wpdb->get_results( "SELECT * FROM $wp_track_table", ARRAY_A );
//print_r($dot_options);
            
//$dot_options = get_option('dot_st_options');
//if($dot_options)
    //$dot_options = json_decode($dot_options, true);

$dot_st_global_token_fee = get_option('dot_st_global_token_fee') ? get_option('dot_st_global_token_fee') :0 ;


?>


<script type="text/javascript">
    var ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
</script>

<h2>Create & Delete Tokens</h2>
<p>Create Tokens which will be used as spenable virtual money for your users.</p>

<hr>
<h3>Token Worth</h3>
<p>Select Token Total Value including fee.</p>
<input type="number" id="dot_token_value" class="dot_token_value" name="dot_token_value" value="30">
<br><br>

<h3>Token Usage Fee</h3>
<p>Amount that will be deducted from Token Value.</p>
<input type="number" id="dot_token_fee" class="dot_token_fee" name="dot_token_fee" value="3">
<br><br>

<button id="dot_create_st">Create Token</button>
<p id="dot_status"></p>
<hr>

<h3>Set Token Usage Fee (Global)</h3>
<p>Amount that will be deducted from Token Value</p>
<input type="number" id="dot_token_fee_global" class="dot_token_fee_global" name="dot_token_fee_global" value="<?php echo $dot_st_global_token_fee; ?>">
<br><br>

<button id="dot_set_token_fee_global">Set Token Fee</button>
<p id="dot_status_global"></p>
<hr>

<br>
<br>
<h2>Active Token</h2>
<table class="wp-list-table widefat fixed striped table-view-list ">
    <thead>
    	<th>Spendable Tokens</th>
    	<th>Worth</th>
    	<th>Used</th>
    	<th>Fee</th>
    	<th>Link</th>
        <th>Reciever</th>
    	<th>Actions</th>
    </thead>
    <tbody>
<?php


if($dot_options){
	foreach($dot_options as $dot_st){
        $key = $dot_st['uniqueToken'];
        $token_value = $dot_st['TokenValue'] - $dot_st['TokenFee'];
        if($token_value <= $dot_st['TokenValueUsed']){
        	$is_active = 'Token Cannot be used again!';
        }else{
        	$is_active = 'Token can be used!';
        }
         
		?>
        	<tr>
            	<td><?php echo $dot_st['uniqueToken']; ?></td>
                <td><?php echo $dot_st['TokenValue']; ?></td>
               	<td><?php echo $dot_st['TokenValueUsed']; ?></td>
               	<td><?php echo $dot_st['TokenFee']; ?></td>
                <td><small><?php echo get_permalink( wc_get_page_id( 'shop' ) ).'?dotst='.$key; ?></small></td>
                <td>
                	<?php echo $dot_st['ReceiverPhone']; ?><br> 
                	<?php echo $dot_st['ReceiverEmail']; ?>
                </td>
                <td>
                    <button class="dot_delete_token" data-st="<?php echo $key; ?>">Delete This Token</button>
                	<br>
                    <p class="dot_status_<?php echo $key; ?>">
                    	<?php echo $is_active; ?>
                    </p>
                </td>
            </tr>     
        <?php
	}
}
	
		





?>