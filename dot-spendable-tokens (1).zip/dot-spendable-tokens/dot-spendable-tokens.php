<?php
/**
* Plugin Name: Dot Spendable Tokens
* Description: Show Only Products according to remaing balance of a price parameter
* Version: 1.0
* Author: Ahmad Malik
* Author URI: https://www.fiverr.com/designotree
* Text Domain: dot-st
*/
    
if( !defined('ABSPATH')){
	exit;
}

//filtering products before showing
add_action('pre_get_posts', 'dot_adjust_products_by_token', 101);
function dot_adjust_products_by_token($query){
   	try{
   
        $dot_filter = false;
        global $woocommerce;
        global $wpdb;
        global $pagenow;
        
        $tblname = 'UserSpendableTokens';
    	$wp_track_table = $wpdb->prefix . "$tblname";
        
        if(!is_woocommerce() || $pagenow == 'edit.php'){
        	return;
        }
        
        if(isset($_GET['dotst'])){
            $dot_st = $_GET['dotst'];
        	//validate token
            $mylink = $wpdb->get_row( "SELECT * FROM $wp_track_table WHERE uniqueToken='".$dot_st."'", ARRAY_A );
            $dot_options = array();
            if(null !== $mylink){
                //print_r($mylink);
                $dot_options[$dot_st] = $mylink;
            }else{
            	exit;
            }
            
            if($dot_options){
                if(isset($dot_options[$dot_st])){
                	$dot_st_value = $dot_options[$dot_st]['TokenValue'];
            		$dot_st_fee = $dot_options[$dot_st]['TokenFee'];
            		$dot_st_allowed = $dot_st_value - $dot_st_fee;
            		$dot_st_used = $dot_options[$dot_st]['TokenValueUsed'];
            		if($dot_st_used >= $dot_st_allowed){
                    	echo "This token is already used. Cannot be used again!<br>";
            		    unset($_COOKIE['dotst']);
            		    $dot_filter = false;
            		}else{
            		    $dot_filter = true;
                        $cookie_name = "dotst";
                        $cookie_value = $dot_st;
                        setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day
            		}
                    
                }else{
                 	$dot_filter = false;	   
                }
            }else{
            	$dot_filter = false;
            }
            
            
            if($dot_filter){
                
                $dot_cart_totals = $woocommerce->cart->subtotal;
                $dot_allowed_value_org = $dot_st_value - $dot_st_fee - $dot_st_used;
				$dot_allowed_value = $dot_allowed_value_org - $dot_cart_totals;
                
                $qtype =  $query->get('post_type');
                
                if ( $qtype == 'product' && $pagenow !== 'admin.php') {

                    
                    if($dot_cart_totals > $dot_allowed_value_org){
                        $woocommerce->cart->empty_cart(); 
                    }

                    $currentMetaQuery[] = [
                        'key' => '_price',
                        'value' => $dot_allowed_value,
                        'type' => 'DECIMAL',
                        'compare' => '<'
                    ];

                    $query->set('meta_query', $currentMetaQuery);
                    $query->set( 'meta_key', '_price' );
                }
            }
            
        }
        elseif(isset($_COOKIE['dotst'])){
            
            $dot_st = $_COOKIE['dotst'];
        	//validate token
            $mylink = $wpdb->get_row( "SELECT * FROM $wp_track_table WHERE uniqueToken='".$dot_st."'", ARRAY_A );
            $dot_options = array();
            if(null !== $mylink){
                //print_r($mylink);
                $dot_options[$dot_st] = $mylink;
            }else{
            	exit;
            }
        	//validate token
            if($dot_options){
                if(isset($dot_options[$dot_st])){
                	$dot_st_value = $dot_options[$dot_st]['TokenValue'];
            		$dot_st_fee = $dot_options[$dot_st]['TokenFee'];
            		$dot_st_allowed = $dot_st_value - $dot_st_fee;
            		$dot_st_used = $dot_options[$dot_st]['TokenValueUsed'];
            		if($dot_st_used >= $dot_st_allowed){
            		    unset($_COOKIE['dotst']);
            		    $dot_filter = false;
            		}else{
            		    $dot_filter = true;
            		}
                }else{
                 	$dot_filter = false;	   
                }
            }else{
            	$dot_filter = false;
            }
            
            
            if($dot_filter){
                
                global $woocommerce;
                $dot_cart_totals = $woocommerce->cart->subtotal;
                $dot_allowed_value_org = $dot_st_value - $dot_st_fee - $dot_st_used;
                $dot_allowed_value = $dot_allowed_value_org - $dot_cart_totals;

                $post_type_product_found = false;
                $wc_query_products_found = false;
                
                
                $qtype =  $query->get('post_type');
                
                if( isset($query->query_vars['post_type']) && $query->query_vars['post_type'] == 'product'){
                	$post_type_product_found = true;
                }elseif(isset($query->query_vars['wc_query']) && $query->query_vars['wc_query'] == 'product_query'){
                    $wc_query_products_found = true;
                }else{
                    $post_type_product_found = false;
                    $wc_query_products_found = false;
                }
                
                //echo $qtype;
                //if ( ($post_type_product_found || $wc_query_products_found) && (is_product_category() || is_product_tag() || is_shop() )) {
                if ($post_type_product_found || $wc_query_products_found) {
                //if ( ! is_admin() && is_post_type_archive( 'product' ) && $query->is_main_query() ) {

                    //echo "cart total: ".$dot_cart_totals;
                    //echo '<br>';
                    //echo "allowed total: ".$dot_allowed_value;
                    if($dot_cart_totals > $dot_allowed_value_org){
                        $woocommerce->cart->empty_cart(); 
                    }

                    $currentMetaQuery[] = [
                        'key' => '_price',
                        'value' => $dot_allowed_value,
                        'type' => 'DECIMAL',
                        'compare' => '<'
                    ];

                    $query->set('meta_query', $currentMetaQuery);
                    $query->set( 'meta_key', '_price' );
                }
            }
        
        }
    }catch(\Exception $e){
    	//print_r($e);
    }
}

//add to cart validation
add_filter( 'woocommerce_add_to_cart_validation', 'remove_cart_item_before_add_to_cart', 20, 3 );
function remove_cart_item_before_add_to_cart( $passed, $product_id, $quantity ) {
    //if( ! WC()->cart->is_empty() )
        //WC()->cart->empty_cart();
    global $woocommerce;
    $_product = wc_get_product( $product_id );
    $product_price = $_product->get_price();
    
    if(isset($_GET['dotst'])){
            $dot_st = $_GET['dotst'];
        	$dot_filter = false;
        
            $mylink = $wpdb->get_row( "SELECT * FROM $wp_track_table WHERE uniqueToken='".$dot_st."'", ARRAY_A );
            $dot_options = array();
            if(null !== $mylink){
                //print_r($mylink);
                $dot_options[$dot_st] = $mylink;
            }else{
            	exit;
            }
        
            //$dot_options = get_option('dot_st_options');
            if($dot_options){
                //$dot_options = json_decode($dot_options, true);
                if(isset($dot_options[$dot_st])){
                	$dot_st_value = $dot_options[$dot_st]['TokenValue'];
            		$dot_st_fee = $dot_options[$dot_st]['TokenFee'];
                    $dot_allowed_amount = $dot_st_value - $dot_st_fee;
                    $dot_filter = true;
                }else{
                 	$dot_filter = false;	   
                }
            }else{
            	$dot_filter = false;
            }
        
        if($dot_filter){
        	$dot_cart_totals = $woocommerce->cart->subtotal;
            if($dot_cart_totals > $dot_allowed_value){
                wc_add_notice( __( 'Cart Total Amount has already exceeded the allowed amount.', 'woocommerce' ), 'error' );
            	$passed = false;
            }
            elseif(($dot_cart_totals+$product_price)>$dot_allowed_value){
                wc_add_notice( __( 'Product Cannot be added to cart, As this will exceed the allowed amount.', 'woocommerce' ), 'error' );
            	$passed = false;
            }else{
             	$passed = true;   
            }
        }
        
        
    }
    return $passed;
}

//if customer is using token, disable payment methods
add_filter( 'woocommerce_cart_needs_payment', 'dotst_filter_cart_needs_payment_callback', 100, 2 );
function dotst_filter_cart_needs_payment_callback( $needs_payment, $cart ) {
    if(isset($_COOKIE['dotst'])){
        global $woocommerce;
        global $wpdb;
        global $pagenow;
        
        $tblname = 'UserSpendableTokens';
    	$wp_track_table = $wpdb->prefix . "$tblname";
        //validate token
            $dot_st = $_COOKIE['dotst'];
            $dot_token_record = $wpdb->get_row( "SELECT * FROM $wp_track_table WHERE uniqueToken='".$dot_st."'", ARRAY_A );
            if(null !== $dot_token_record){
                $dot_token_total = $dot_token_record['TokenValue'];
                $dot_token_allowed = $dot_token_record['TokenValue'] - $dot_token_record['TokenFee'];
                $dot_token_left = $dot_token_allowed - $dot_token_record['TokenValueUsed'];
                if($cart->subtotal <= $dot_token_left){
                    return false;
                }else{
                    return $needs_payment;
                }
            }else{
            	return $needs_payment;
            }
        
    }
    
}

/**
 * Register a dot-st menu page.
 */
add_action( 'admin_menu', 'dot_register_dot_st_menu_page' );
function dot_register_dot_st_menu_page() {
    add_menu_page(
        __( 'Dot Tokens', 'dot-st' ), //page title
        'Dot Spendable Tokens', //menu title
        'manage_options', //capability
        'dot-spendable-tokens/dot-spendable-tokens-admin.php', //menu slug
        '', //callback function (render function)
        'dashicons-xing',
        6 //position
    );
}

//adding javascript and style to dot-st menu page
add_action( 'admin_enqueue_scripts', 'dot_add_scripts_to_dot_st_menu_page' );
function dot_add_scripts_to_dot_st_menu_page()
{
    global $pagenow;
    
    if ($pagenow != 'admin.php') {
        return;
    }
    // loading css
    wp_register_style( 'dot-st-css', plugins_url( 'css/dot_style.css' , __FILE__ ), false, '1.0.0' );
    wp_enqueue_style( 'dot-st-css' );
     
    // loading js
    wp_register_script( 'dot-st-js', plugins_url( 'js/dot_script.js' , __FILE__ ), array('jquery-core'), false, true );
    wp_enqueue_script( 'dot-st-js' );
}


// ajax function that gets called to create new tokens
add_action("wp_ajax_dot_set_token_fee", "dot_set_token_fee");

function dot_set_token_fee(){
	if ( isset( $_POST['dot_token_fee'] ) ) {
    	$status = update_option('dot_st_global_token_fee', $_POST['dot_token_fee']);
        $return = array( 'message' => "New Tokne Fee is saved." );
        wp_send_json( $return );
    }else{
    	$return = array( 'message' => "Error: Make sure Token fee is valid!!!" );
        wp_send_json( $return );
    }
}



// ajax function that gets called to create new tokens
add_action("wp_ajax_dot_create_token", "dot_create_token");

function dot_create_token() {
    if ( isset( $_POST['dot_token_value'] ) &&  isset( $_POST['dot_token_fee'] ) ) {
        $dot_token_value  = $_POST['dot_token_value'];
        $dot_token_fee  = $_POST['dot_token_fee'];
        
        if ( !empty( $dot_token_value ) && !empty( $dot_token_fee ) ) {
            
            //creating dot-st-code
            $dot_options = get_option('dot_st_options');
            if($dot_options){
                $dot_options = json_decode($dot_options, true);
            }else{
            	$dot_options = array();
            }
            $dot_token_code = dot_generate_token_code();
            $dot_options[$dot_token_code] = array(
                'TokenValue' => $dot_token_value,
                'TokenFee' => $dot_token_fee,
                'uniqueToken' => $dot_token_code,
            );
            dot_save_token($dot_options[$dot_token_code]);
            //$status = update_option('dot_st_options', json_encode($dot_options));
            
        }
        $return = array( 'message' => "New token is created. Here it is." );
        wp_send_json( $return );
    }else{
        $return = array( 'message' => "Error: Make sure all field are filled correctly!!!" );
        wp_send_json( $return );
    }
    
}

function dot_save_token($dot_token_array){
    global $wpdb;
    $tblname = 'UserSpendableTokens';
    $wp_track_table = $wpdb->prefix . "$tblname";
    $re_email = $dot_token_array['ReceiverEmail'] ? $dot_token_array['ReceiverEmail']:'';
    $re_phone = $dot_token_array['ReceiverPhone'] ? $dot_token_array['ReceiverPhone']:'';
    
    $dot_db = array(
    	'id' => NULL,
    	'uniqueToken' => $dot_token_array['uniqueToken'],
        'TokenValue' => $dot_token_array['TokenValue'],
        'TokenFee' => $dot_token_array['TokenFee'],
    	'TokenCreatedDate' => current_time('mysql', 1),
        'TokenUpdatedDate' => current_time('mysql', 1),
        'userId' => get_current_user_id(),
        'TokenCreatedBy' => get_current_user_id(),
        'TokenValueUsed' => 0,
        'ReceiverEmail' => $re_email,
        'ReceiverPhone' => $re_phone,
    );
                                                    
    $wpdb->insert($wp_track_table, $dot_db);
}


// ajax function that gets called to delete tokens
add_action("wp_ajax_dot_delete_token", "dot_delete_token");

function dot_delete_token() {
    if ( isset( $_POST['dot_token'] ) ) {
        $dot_token  = $_POST['dot_token'];
        global $wpdb;
        $tblname = 'UserSpendableTokens';
    	$wp_track_table = $wpdb->prefix . "$tblname";
        
        if ( !empty( $dot_token ) ) {
            
            //Deleting dot-st-code
            $wpdb->delete( $wp_track_table, array( 'uniqueToken' => $dot_token ) );
            
        }
        $return = array( 'message' => "Token Deleted." );
        wp_send_json( $return );
    }else{
        $return = array( 'message' => "Error: Contact Support!!!" );
        wp_send_json( $return );
    }
    
}

//Dot-function to generate random token codes
function dot_generate_token_code($length=10)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

add_action( 'wp_footer', 'trigger_for_ajax_add_to_cart' );
function trigger_for_ajax_add_to_cart() {
    ?>
        <script type="text/javascript">
            (function($){
                $('body').on( 'added_to_cart', function(){
                    // Testing output on browser JS console
                    location.reload();
                    // Your code goes here
                });
            })(jQuery);
        </script>
    <?php
}

add_action( 'wp_footer', 'trigger_for_ajax_removed_from_cart' );
function trigger_for_ajax_removed_from_cart() {
    ?>
        <script type="text/javascript">
            (function($){
                $('body').on( 'removed_from_cart', function(){
                    // Testing output on browser JS console
                    location.reload();
                    // Your code goes here
                });
            })(jQuery);
        </script>
    <?php
}


function dot_st_activate() { 
    global $wpdb;

      	$tblname = 'UserSpendableTokens';
      	$wp_track_table = $wpdb->prefix . "$tblname";

      	$sql = "CREATE TABLE IF NOT EXISTS $wp_track_table ( ";
      	$sql .= "  `id`  int(11)   NOT NULL auto_increment primary key, ";
      	$sql .= "  `userId`  int(128)   NULL, ";
    	$sql .= "  `uniqueToken`  varchar(255)   NOT NULL, ";
    	$sql .= "  `TokenValue`  int(128)   NOT NULL, ";
    	$sql .= "  `TokenFee`  int(128)   NOT NULL, ";
    	$sql .= "  `TokenValueUsed`  int(128)  NULL, ";
    	$sql .= "  `TokenCreatedBy`  int(128)   NULL, ";
    	$sql .= "  `TokenCreatedDate`  datetime  NULL, ";
    	$sql .= "  `TokenUpdatedDate`  datetime   NULL, ";
    	$sql .= "  `TokenStatus`  bool  NULL,";
        $sql .= "  `ReceiverEmail` varchar(250)  NULL,";
        $sql .= "  `ReceiverPhone` varchar(15) NULL";
         
      	$sql .= ") ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ; ";
      require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
    try{
      dbDelta($sql);
    }catch(Exception $e){
    	//print_r($e);
    }
    
}
register_activation_hook( __FILE__, 'dot_st_activate' );


add_filter( 'woocommerce_checkout_fields' , 'virtual_products_less_fields' );
 
function virtual_products_less_fields( $fields ) {
     
    // set our flag to be true until we find a product that isn't virtual
    $virtual_products = true;
     
    // loop through our cart
    foreach( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
     // Check if there are non-virtual products and if so make it false
        if ( ! $cart_item['data']->is_virtual() ) $virtual_products = false; 
    }

    // only unset fields if virtual_products is true so we have no physical products in the cart
    if( $virtual_products===true) {
    	 
        unset($fields['billing']['billing_company']);
        unset($fields['billing']['billing_address_1']);
        unset($fields['billing']['billing_address_2']);
        unset($fields['billing']['billing_city']);
        unset($fields['billing']['billing_postcode']);
        unset($fields['billing']['billing_country']);
        unset($fields['billing']['billing_state']);
        unset($fields['billing']['billing_phone']);
        //Removes Additional Info title and Order Notes
        add_filter( 'woocommerce_enable_order_notes_field', '__return_false',9999 ); 
    }
     
    return $fields;
}

//add_action( 'woocommerce_payment_complete', 'dot_payment_complete' );
function dot_payment_complete( $order_id ){  
  	$order = wc_get_order( $order_id );
  	$products = $order->get_items();

    foreach($products as $prod){
      if($prod['product_id']==24){
      	
      }
    }

}

add_action('woocommerce_thankyou', 'dot_create_token_for_customer', 10, 1);

function dot_create_token_for_customer($order_id) { 

	//gettinh global token fee
    $dot_st_global_token_fee = get_option('dot_st_global_token_fee') ? get_option('dot_st_global_token_fee') :0 ;
    
    //create an order instance
    $order = wc_get_order($order_id); 
    $products = $order->get_items();
    
    $sender_email  = $order->get_billing_email();
    $sender_name = $order->get_billing_first_name().' '.$order->get_billing_last_name();
      	
    foreach($products as $prod){
        $is_dotst = false;
        $_product = wc_get_product( $prod['product_id'] );
        if( has_term( 'Send Spendable Balance', 'product_cat', $prod['product_id'] ) ){
            $is_dotst = true;
        }
        if( $is_dotst && $_product->is_virtual() ) {
            $receiver_email = wc_get_order_item_meta( $prod->get_id(), '_Receiver Email', true);
            $receiver_phone = wc_get_order_item_meta( $prod->get_id(), '_Receiver Phone', true);
            
            $dot_options=array();
            $dot_token_code = dot_generate_token_code();
            $dot_token_value = $order->get_total();
            $dot_token_fee = $dot_st_global_token_fee;
            $dot_options[$dot_token_code] = array(
                'TokenValue' => $dot_token_value,
                'TokenFee' => $dot_token_fee,
                'uniqueToken' => $dot_token_code,
                'ReceiverEmail' => $receiver_email,
                'ReceiverPhone' => $receiver_phone,
            );
            dot_save_token($dot_options[$dot_token_code]);
            $dot_link = get_permalink( wc_get_page_id( 'shop' ) ).'?dotst='.$dot_token_code;
          	update_post_meta( $order_id,'_dot_spendable_link', $dot_link  );
          	
          	$site_e_mail = get_option( 'admin_email' );
          	$shop = get_bloginfo( 'name' );
          	$allmeta = $prod->get_meta_data();
            //echo '<pre>';
          	//print_r($allmeta);
          	//echo '</pre>';
          	$to = $receiver_email;
            $subject = $sender_name.' sent you balance to shop from ifippo.';
            $body = '<h2>Congrats!</h2><p> '.$sender_name.' has send you balance. Copy this link to use it.<br> '.$dot_link.' <br>Thanks<br> ';
            $headers = array('Content-Type: text/html; charset=UTF-8','From: '.$shop.' <'.$site_e_mail.'>');
     
            wp_mail( $to, $subject, $body, $headers );
            //echo get_post_meta( $order_id, '_dot_spendable_link', true ); 
        
        }
        else{
            if(isset($_COOKIE['dotst'])){
                global $wpdb;
                $tblname = 'UserSpendableTokens';
                $wp_track_table = $wpdb->prefix . "$tblname";
                
                //validate token
                $dot_st = $_COOKIE['dotst'];
                $dot_token_record = $wpdb->get_row( "SELECT * FROM $wp_track_table WHERE uniqueToken='".$dot_st."'", ARRAY_A );
                if(null !== $dot_token_record){
                    $dot_token_total = $dot_token_record['TokenValue'];
                    $dot_token_allowed = $dot_token_record['TokenValue'] - $dot_token_record['TokenFee'];
                    $dot_token_left = $dot_token_allowed - $dot_token_record['TokenValueUsed'];
                    
                    if($order->get_total() < $dot_token_left){
                        //token used fully - update token
                        $dot_now_left = $dot_token_left - $order->get_total();
                        $dot_now_used = $dot_token_allowed - $dot_now_left;
                        $dot_db = array(
                    	    'uniqueToken' => $dot_token_record['uniqueToken'],
                            'TokenUpdatedDate' => current_time('mysql', 1),
                            'TokenValueUsed' => $dot_now_used,
                        );
                        $dot_where = array(
                    	    'uniqueToken' => $dot_token_record['uniqueToken']
                        );
                                                                    
                        $wpdb->update($wp_track_table, $dot_db, $dot_where);
                    }
                    else{
                        //add order total to used
                        $dot_db = array(
                    	    'uniqueToken' => $dot_token_record['uniqueToken'],
                            'TokenUpdatedDate' => current_time('mysql', 1),
                            'TokenValueUsed' => $dot_token_allowed,
                        );
                        $dot_where = array(
                    	    'uniqueToken' => $dot_token_record['uniqueToken']
                        );
                                                                    
                        $wpdb->update($wp_track_table, $dot_db, $dot_where);
                    }
                }
            }
        }
    }
}



//add_action( 'woocommerce_thankyou', 'misha_view_order_and_thankyou_page', 20 );
//add_action( 'woocommerce_view_order', 'misha_view_order_and_thankyou_page', 20 );
add_action( 'woocommerce_order_details_after_order_table','dotst_view_order_and_thankyou_page', 20 );

function dotst_view_order_and_thankyou_page( $order_id ){ 

    $spendable_link = get_post_meta( $order_id->id, '_dot_spendable_link',true );
    if($spendable_link){
    ?>
        <h3 style="margin-bottom:0px;">Spendable Balance Link</h3>
    	<p>You can Copy This link and Share it with the receiver!! Thanks! </p>
        <div style="background: bisque;border-radius: 4px;padding: 8px 12px;color: black;margin-bottom:30px;">
        <?php
            echo get_post_meta( $order_id->id, '_dot_spendable_link',true );
        ?>
        </div>
    
    <?php
    }
}

add_action( 'woocommerce_admin_order_data_after_billing_address', 'dotst_custom_checkout_field_display_admin_order_meta', 10, 1 );

function dotst_custom_checkout_field_display_admin_order_meta($order){
    echo '<p><strong>'.__('Spendable Balance Link').':</strong> <br/>'.get_post_meta( $order->id, '_dot_spendable_link',true ) . '</p>';
}